# Chaoxing Scanner

学习通作业扫描器 - 自动登录学习通，发现课程，扫描未交作业

## 安装

```bash
unzip chaoxing-scanner.skill.zip
cd chaoxing-scanner
bash install.sh
```

## 使用

```bash
/chaoxing-scanner
```

或

```bash
bash skill.sh
```

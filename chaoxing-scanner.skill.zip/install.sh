#!/bin/bash

# ============================================
# 安装脚本 - 学习通作业扫描器
# ============================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/.claude/skills"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info()  { echo -e "${BLUE}[INFO]${NC} $1"; }
print_ok()    { echo -e "${GREEN}[OK]${NC} $1"; }
print_warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 创建安装目录
create_install_dir() {
    if [ ! -d "$INSTALL_DIR" ]; then
        print_info "创建安装目录: $INSTALL_DIR"
        mkdir -p "$INSTALL_DIR"
    fi
}

# 安装skill
install_skill() {
    local skill_dir="$INSTALL_DIR/chaoxing-scanner"

    print_info "安装skill到: $skill_dir"

    if [ -d "$skill_dir" ]; then
        print_warn "skill已存在，正在更新..."
        rm -rf "$skill_dir"
    fi

    mkdir -p "$skill_dir"

    # 复制文件
    cp "$SCRIPT_DIR/skill.sh" "$skill_dir/"
    cp "$SCRIPT_DIR/scanner.js" "$skill_dir/"
    cp "$SCRIPT_DIR/package.json" "$skill_dir/"
    cp "$SCRIPT_DIR/SKILL_chaoxing-scanner.md" "$skill_dir/"

    # 设置执行权限
    chmod +x "$skill_dir/skill.sh"

    print_ok "skill文件已复制"

    # 安装依赖
    print_info "安装npm依赖..."
    cd "$skill_dir"
    npm install 2>&1 | grep -E "(added|changed|up to date)" || true

    print_ok "依赖安装完成"

    # 创建符号链接到PATH
    if [ ! -L "/usr/local/bin/chaoxing-scanner" ]; then
        print_info "创建命令链接..."
        sudo ln -sf "$skill_dir/skill.sh" /usr/local/bin/chaoxing-scanner 2>/dev/null || \
        ln -sf "$skill_dir/skill.sh" "$HOME/.local/bin/chaoxing-scanner" 2>/dev/null || \
        print_warn "无法创建PATH链接，请手动添加"
    fi
}

# 显示安装信息
show_info() {
    echo ""
    echo "========================================="
    echo "  安装完成！"
    echo "========================================="
    echo ""
    echo "📂 Skill位置: $INSTALL_DIR/chaoxing-scanner"
    echo ""
    echo "🚀 使用方法："
    echo ""
    echo "   1. 命令行执行:"
    echo "      bash $INSTALL_DIR/chaoxing-scanner/skill.sh"
    echo ""
    echo "   2. 在Claude Code中执行:"
    echo "      /chaoxing-scanner"
    echo ""
    echo "   3. 如果已添加PATH，直接执行:"
    echo "      chaoxing-scanner"
    echo ""
    echo "📝 参数说明:"
    echo "   -h, --help     显示帮助"
    echo "   -p, --phone    手机号"
    echo "   -d, --password 密码"
    echo "   -c, --course   课程序号"
    echo "   --debug        调试模式"
    echo ""
    echo "========================================="
    echo ""
}

# 清理函数
cleanup() {
    print_info "清理临时文件..."
    rm -f "$INSTALL_DIR/chaoxing-scanner/.chaoxing-session.json"
}

# 主流程
main() {
    echo ""
    echo "📦 安装学习通作业扫描器"
    echo ""

    create_install_dir
    install_skill
    cleanup
    show_info
}

main "$@"

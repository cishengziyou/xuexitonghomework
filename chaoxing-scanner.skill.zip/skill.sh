#!/bin/bash

# ============================================
# 学习通作业扫描器 (chaoxing-scanner)
# ============================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STATE_FILE="$SCRIPT_DIR/.chaoxing-session.json"

# 颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info()  { echo -e "${BLUE}[INFO]${NC} $1"; }
print_ok()    { echo -e "${GREEN}[OK]${NC} $1"; }
print_warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 检查依赖
check_deps() {
    if ! command -v node &> /dev/null; then
        print_error "需要 Node.js，请先安装"
        exit 1
    fi

    if ! command -v npx &> /dev/null; then
        print_error "需要 npx，请先安装 npm"
        exit 1
    fi

    # 检查 playwright 是否安装
    if [ ! -d "$SCRIPT_DIR/node_modules/playwright" ]; then
        print_warn "Playwright 未安装，正在安装..."
        npm install playwright -w "$SCRIPT_DIR"
    fi
}

# 显示使用方法
show_usage() {
    echo "
📚 学习通作业扫描器

用法: $0 [选项]

选项:
  -p, --phone PHONE      手机号（账号）
  -d, --password PWD     密码
  -c, --course IDS       课程序号，逗号分隔（如: 1,2,3 或 all）
  -m, --mode MODE        扫描模式:
                          scan    - 扫描作业（默认）
                          discover - 仅发现课程
  -o, --output FILE      输出文件（默认: stdout）
  --debug                调试模式，显示详细日志
  --clean                清理会话文件
  -h, --help             显示此帮助

示例:
  # 交互式扫描（会提示输入）
  $0

  # 指定账号密码扫描
  $0 -p 13213732826 -d mypassword

  # 仅发现课程
  $0 -m discover

  # 扫描特定课程
  $0 -c 1,2,3

  # 扫描全部课程
  $0 -c all

  # 调试模式
  $0 --debug

  # 输出到文件
  $0 -o result.txt
"
}

# 清理会话
clean_session() {
    if [ -f "$STATE_FILE" ]; then
        rm "$STATE_FILE"
        print_ok "已清理会话文件: $STATE_FILE"
    else
        print_info "无会话文件需要清理"
    fi
}

# 运行扫描器
run_scanner() {
    local phone="$1"
    local password="$2"
    local courses="$3"
    local mode="$4"
    local debug="$5"
    local output="$6"

    # 构造 Node.js 命令参数
    local node_args=()

    if [ -n "$phone" ]; then
        node_args+=("--phone" "$phone")
    fi
    if [ -n "$password" ]; then
        node_args+=("--password" "$password")
    fi
    if [ -n "$courses" ]; then
        node_args+=("--courses" "$courses")
    fi
    if [ -n "$mode" ]; then
        node_args+=("--mode" "$mode")
    fi
    if [ "$debug" = "true" ]; then
        node_args+=("--debug")
    fi

    # 执行 Node.js 脚本
    if [ -n "$output" ]; then
        node "$SCRIPT_DIR/scanner.js" "${node_args[@]}" | tee "$output"
    else
        node "$SCRIPT_DIR/scanner.js" "${node_args[@]}"
    fi
}

# ============================================
# 主流程
# ============================================

main() {
    local phone=""
    local password=""
    local courses=""
    local mode="scan"
    local debug="false"
    local output=""
    local clean="false"

    # 解析参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            -p|--phone)
                phone="$2"
                shift 2
                ;;
            -d|--password)
                password="$2"
                shift 2
                ;;
            -c|--course)
                courses="$2"
                shift 2
                ;;
            -m|--mode)
                mode="$2"
                shift 2
                ;;
            -o|--output)
                output="$2"
                shift 2
                ;;
            --debug)
                debug="true"
                shift
                ;;
            --clean)
                clean="true"
                shift
                ;;
            -h|--help)
                show_usage
                exit 0
                ;;
            *)
                print_error "未知参数: $1"
                show_usage
                exit 1
                ;;
        esac
    done

    # 如果指定了 --clean，清理后退出
    if [ "$clean" = "true" ]; then
        clean_session
        exit 0
    fi

    # 检查依赖
    check_deps

    # 运行扫描器
    run_scanner "$phone" "$password" "$courses" "$mode" "$debug" "$output"
}

main "$@"

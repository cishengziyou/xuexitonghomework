const { chromium } = require('playwright');
const fs = require('fs');
const readline = require('readline');

// ==================== 配置 ====================
let PHONE = '';
let PASSWORD = '';
const STATE_PATH = './.chaoxing-session.json';
let debug = false;
let mode = 'scan';
let selectedCourseIds = null;

// ==================== 参数解析 ====================
function parseArgs() {
  const args = process.argv.slice(2);
  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--phone':
      case '-p':
        PHONE = args[++i] || '';
        break;
      case '--password':
      case '-d':
        PASSWORD = args[++i] || '';
        break;
      case '--courses':
      case '-c':
        const coursesArg = args[++i] || '';
        if (coursesArg.toLowerCase() === 'all') {
          selectedCourseIds = 'all';
        } else {
          selectedCourseIds = coursesArg.split(',').map(id => parseInt(id.trim()) - 1).filter(id => !isNaN(id));
        }
        break;
      case '--mode':
      case '-m':
        mode = args[++i] || 'scan';
        break;
      case '--debug':
        debug = true;
        break;
    }
  }
}

// ==================== 工具函数 ====================
function log(msg) {
  if (debug) console.log(`[debug] ${msg}`);
  else console.log(msg);
}

function extractCpi(page) {
  const url = page.url();
  const match = url.match(/[?&]cpi=(\d+)/);
  if (match) return match[1];
  return null;
}

// ==================== 登录函数 ====================
async function login(page) {
  log('正在打开学习通登录页...');

  try {
    await page.goto('https://i.chaoxing.com/base', {
      waitUntil: 'networkidle',
      timeout: 30000
    });

    await page.waitForTimeout(2000);
    const currentUrl = page.url();

    if (currentUrl.includes('passport') || currentUrl.includes('login')) {
      log('已跳转到登录页面');

      // 如果没有提供账号密码，交互式获取
      if (!PHONE || !PASSWORD) {
        const rl = readline.createInterface({
          input: process.stdin,
          output: process.stdout
        });

        PHONE = await new Promise(resolve => {
          rl.question('请输入手机号: ', answer => {
            rl.close();
            resolve(answer);
          });
        });

        const rl2 = readline.createInterface({
          input: process.stdin,
          output: process.stdout
        });

        PASSWORD = await new Promise(resolve => {
          rl2.question('请输入密码: ', answer => {
            rl2.close();
            resolve(answer);
          });
        });
      }

      log('输入账号...');
      const usernameSelector = 'input[type="text"], input[name="phone"], input[name="account"]';
      await page.waitForSelector(usernameSelector, { timeout: 10000 });
      await page.fill(usernameSelector, PHONE);
      await page.waitForTimeout(500);

      log('输入密码...');
      const passwordSelector = 'input[type="password"]';
      await page.waitForSelector(passwordSelector, { timeout: 5000 });
      await page.fill(passwordSelector, PASSWORD);
      await page.waitForTimeout(500);

      log('点击登录...');
      const loginButton = await page.locator('button:has-text("登录"), a:has-text("登录"), input[type="submit"]').first();
      await loginButton.click();

      log('等待登录完成...');

      for (let i = 0; i < 30; i++) {
        await page.waitForTimeout(2000);
        const url = page.url();

        if (url.includes('i.chaoxing.com/base') || !url.includes('passport')) {
          log('登录成功！');
          return true;
        }

        const pageText = await page.evaluate(() => document.body.innerText);
        if (pageText.includes('验证码') || pageText.includes('错误') || pageText.includes('失败')) {
          throw new Error('登录失败：' + pageText.slice(0, 100));
        }
      }

      throw new Error('登录超时（60秒）');
    } else {
      log('已自动登录（已有会话）');
      return true;
    }
  } catch (error) {
    throw new Error('登录失败：' + error.message);
  }
}

// ==================== 发现课程 ====================
async function discoverCourses(page) {
  log('正在发现课程...');

  try {
    let courses = await discoverFromUrl(page, 'https://mooc1.chaoxing.com/visit/course/list');
    if (courses.length > 0) return courses;

    const fallbackUrls = [
      'https://mooc1.chaoxing.com/visit/courseschool',
      'https://mooc1.chaoxing.com/mycourse',
      'https://mooc1.chaoxing.com/visit/interaction'
    ];

    for (const url of fallbackUrls) {
      log(`尝试 ${url}...`);
      courses = await discoverFromUrl(page, url);
      if (courses.length > 0) {
        log(`从 ${url} 发现 ${courses.length} 门课程`);
        return courses;
      }
    }

    throw new Error('未发现任何课程');
  } catch (error) {
    throw new Error('课程发现失败：' + error.message);
  }
}

async function discoverFromUrl(page, url) {
  try {
    await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
    await page.waitForTimeout(2000);

    const courses = await page.evaluate(() => {
      const results = [];
      const courseElements = document.querySelectorAll('a[href*="courseid"], [data-courseid]');

      for (const el of courseElements) {
        const href = el.getAttribute('href') || '';
        const text = el.textContent.trim();
        const courseIdMatch = href.match(/courseid=(\d+)/);
        const clazzIdMatch = href.match(/clazzid=(\d+)/);

        if (courseIdMatch && text && text.length > 3 && !text.includes('学习通')) {
          results.push({
            courseid: courseIdMatch[1],
            clazzid: clazzIdMatch ? clazzIdMatch[1] : '',
            name: text.slice(0, 100)
          });
        }
      }

      return results;
    });

    const unique = [...new Map(courses.map(c => [c.courseid, c])).values()];
    log(`从URL ${url} 提取到 ${unique.length} 门课程`);

    return unique;
  } catch (error) {
    return [];
  }
}

// ==================== 获取真实课程名 ====================
async function getRealCourseName(page, course) {
  try {
    const url = `https://mooc1.chaoxing.com/mooc-ans/visit/stucoursemiddle?courseid=${course.courseid}&clazzid=${course.clazzid}&vc=1&ismooc2=1&v=2`;
    await page.goto(url, { waitUntil: 'networkidle', timeout: 20000 });
    await page.waitForTimeout(1500);

    const courseName = await page.evaluate(() => {
      const titleEl = document.querySelector(
        '.course-name, .course-title, h1, h2, ' +
        '[class*="course-name"], [class*="course-title"], ' +
        '[class*="courseName"], [class*="courseTitle"]'
      );
      if (titleEl) return titleEl.textContent.trim();

      if (document.title && !document.title.includes('学习通')) {
        return document.title;
      }

      return '';
    });

    return courseName || '未知课程';
  } catch (error) {
    return '未知课程';
  }
}

// ==================== 扫描作业 ====================
async function scanHomework(page, course, cpi) {
  log(`扫描 ${course.name} 的作业...`);

  try {
    const url = `https://mooc1.chaoxing.com/mooc-ans/visit/stucoursemiddle?courseid=${course.courseid}&clazzid=${course.clazzid}&vc=1&cpi=${cpi}&ismooc2=1&v=2`;
    await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
    await page.waitForTimeout(2000);

    await page.evaluate(() => {
      const allEls = document.querySelectorAll('a, span, div, li');
      for (const el of allEls) {
        if (el.textContent && el.textContent.trim() === '作业') {
          el.click();
          return;
        }
      }
    });

    await page.waitForTimeout(3000);

    let frame = page.frames().find(f => f.url().includes('/work/list'));
    if (!frame) {
      frame = page.frames().find(f =>
        f.name() && (f.name().includes('frame_content') || f.name().includes('zy'))
      );
    }

    if (!frame) {
      throw new Error('未找到作业iframe');
    }

    const homework = await frame.evaluate(() => {
      const results = [];
      const items = document.querySelectorAll(
        '.homeworkItem, .zyItem, tr, .list-item, .item, li'
      );

      items.forEach(item => {
        const titleEl = item.querySelector('.title, .name, h3, h4, a, [class*="title"]');
        const title = titleEl?.textContent?.trim();
        if (!title || title.length < 3) return;

        const statusEl = item.querySelector('.status, .state, [class*="status"]');
        const status = statusEl?.textContent?.trim() || '';

        const deadlineEl = item.querySelector('.deadline, .time, .endtime, [class*="deadline"], [class*="time"]');
        const deadline = deadlineEl?.textContent?.trim() || '';

        results.push({ title, status, deadline });
      });

      return results;
    });

    const pending = homework.filter(hw =>
      hw.status.includes('未交') || hw.status.includes('未完成')
    );

    log(`${course.name}: 发现 ${pending.length} 个未交作业`);

    return pending.map(hw => ({
      name: hw.title,
      status: hw.status,
      deadline: hw.deadline,
      source: 'DOM'
    }));
  } catch (error) {
    log(`${course.name}: 扫描失败 - ${error.message}`);
    return [];
  }
}

// ==================== 估算时间 ====================
function estimateTime(name) {
  if (name.includes('视频') || name.includes('拍摄') || name.includes('剪辑')) return '预计2小时';
  if (name.includes('H5') || name.includes('录屏') || name.includes('PPT')) return '预计1小时';
  if (name.includes('数据') || name.includes('可视化') || name.includes('分析')) return '预计20分钟';
  if (name.includes('策划') || name.includes('方案') || name.includes('报道')) return '预计30分钟';
  if (name.includes('案例') || name.includes('评论')) return '预计15分钟';
  return '预计15分钟';
}

// ==================== 主流程 ====================
async function main() {
  parseArgs();

  console.log('学习通作业扫描器启动\n');

  const browser = await chromium.launch({
    headless: false,
  });

  const context = await browser.newContext({
    storageState: fs.existsSync(STATE_PATH) ? STATE_PATH : undefined,
    viewport: { width: 1400, height: 900 },
    locale: 'zh-CN',
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
  });

  await context.route('**', async route => {
    const headers = {
      ...route.request().headers(),
      'referer': 'https://i.chaoxing.com/',
      'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8',
    };
    await route.continue({ headers });
  });

  const page = await context.newPage();

  try {
    await login(page);
    await context.storageState({ path: STATE_PATH });

    const cpi = extractCpi(page);
    if (!cpi) {
      await page.goto('https://mooc1.chaoxing.com/visit/course/list', {
        waitUntil: 'networkidle',
        timeout: 30000
      });
      await page.waitForTimeout(2000);
      const cpiFromPage = extractCpi(page);
      if (!cpiFromPage) {
        throw new Error('无法获取CPI，请检查登录状态');
      }
    }

    const finalCpi = cpi || extractCpi(page);
    log(`CPI: ${finalCpi}`);

    const courses = await discoverCourses(page);
    console.log(`\n发现 ${courses.length} 门课程：\n`);
    courses.forEach((c, i) => {
      console.log(`${i + 1}. ${c.name}`);
    });

    log('\n获取真实课程名...');
    for (let i = 0; i < courses.length; i++) {
      const realName = await getRealCourseName(page, courses[i]);
      if (realName && realName !== '未知课程') {
        courses[i].name = realName;
        log(`[${i + 1}] ${realName}`);
      }
    }

    // 用户选择
    if (selectedCourseIds === null) {
      console.log('\n请在控制台输入要扫描的课程序号（用逗号分隔，或输入 all 扫描全部）：');
      console.log('示例：1,2,3 或 all');

      const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
      });

      const input = await new Promise(resolve => {
        rl.question('> ', answer => {
          rl.close();
          resolve(answer);
        });
      });

      if (input.toLowerCase() === 'all' || input === '全部') {
        selectedCourseIds = 'all';
        console.log('\n选择扫描全部课程');
      } else {
        selectedCourseIds = input.split(',').map(i => parseInt(i.trim()) - 1).filter(i => i >= 0 && i < courses.length);
        console.log(`\n选择 ${selectedCourseIds.length} 门课程`);
      }
    }

    let selectedCourses;
    if (selectedCourseIds === 'all') {
      selectedCourses = courses;
    } else {
      selectedCourses = selectedCourseIds.map(i => courses[i]);
    }

    if (selectedCourses.length === 0) {
      throw new Error('未选择任何课程');
    }

    console.log('\n开始扫描作业...\n');

    const results = [];
    for (const course of selectedCourses) {
      const pending = await scanHomework(page, course, finalCpi);
      results.push({
        course: course.name,
        pending
      });
    }

    // 输出结果
    console.log('\n' + '='.repeat(60));
    console.log('学习通作业扫描结果\n');

    let totalPending = 0;
    for (const result of results) {
      console.log(`📘 ${result.course}`);

      if (result.pending.length === 0) {
        console.log('  ✓ 没有未交作业\n');
        continue;
      }

      result.pending.forEach(hw => {
        const timeEstimate = estimateTime(hw.name);
        console.log(`  [AI能做] ${hw.name} — ${hw.status}`);
        console.log(`  [${timeEstimate}]`);
        if (hw.deadline) {
          console.log(`  [截止] ${hw.deadline}`);
        }
        console.log('');
        totalPending++;
      });
    }

    console.log('='.repeat(60));
    console.log(`\n总计：${totalPending} 个未交作业\n`);

    console.log('要我帮你完成这些作业吗？直接告诉我序号就行。');
    console.log('所有作业提交会经过查重系统，建议改写后再交。\n');

  } catch (error) {
    console.error('\n错误：' + error.message);
    if (debug) console.error(error);
  } finally {
    console.log('\n提示：会话文件 .chaoxing-session.json 包含登录态数据，请手动删除');
    await browser.close();
  }
}

main();
